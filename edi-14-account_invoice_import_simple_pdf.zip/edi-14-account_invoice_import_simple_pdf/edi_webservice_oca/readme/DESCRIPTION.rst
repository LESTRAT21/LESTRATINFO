This module creates WebService frameworks to be used on EDI
