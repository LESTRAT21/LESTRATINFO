from . import account_invoice_import_simple_pdf_fields
from . import account_invoice_import_simple_pdf_invoice_number
from . import res_partner
