You will find a full demonstration about how to configure and use this module in this `screencast <https://www.youtube.com/watch?v=edsEuXVyEYE>`_.
