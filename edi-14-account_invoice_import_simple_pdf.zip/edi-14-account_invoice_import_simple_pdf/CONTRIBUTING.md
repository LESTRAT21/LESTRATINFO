# OCA Guidelines

Please follow the official guide from the
[OCA Guidelines page](https://odoo-community.org/page/contributing).

## Project Specific Guidelines

<!-- /!\ do not modify above this line -->

This project does not have specific coding guidelines.
