This module creates WebService frameworks to be used globally
